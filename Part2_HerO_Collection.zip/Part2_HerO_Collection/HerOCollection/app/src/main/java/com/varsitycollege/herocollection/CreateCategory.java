package com.varsitycollege.herocollection;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.appcompat.app.ActionBar;
import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.net.Uri;
import android.os.Bundle;
import android.provider.MediaStore;
import android.text.TextUtils;
import android.view.MenuItem;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ImageButton;
import android.widget.ImageView;
import android.widget.Toast;


import com.google.android.gms.tasks.OnFailureListener;
import com.google.android.gms.tasks.OnSuccessListener;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.storage.FirebaseStorage;
import com.google.firebase.storage.StorageReference;
import com.google.firebase.storage.UploadTask;

import java.util.UUID;

public class CreateCategory extends AppCompatActivity
{
    private FirebaseDatabase database = FirebaseDatabase.getInstance();
    private DatabaseReference heroCollec = database.getReference("categories");
    private Category category;

    private EditText etCate;
    private EditText etCreatedName;
    private EditText etGoal;
    private Button btnNext;
    private Button btnDone1;
    private Button btnCancel2;
    private Button btnLogoutCat;
    private Button img;
    private Button imgUploads;
    private ImageView imgShow;

    private Uri selectImg;

    FirebaseStorage storage;
    StorageReference storeRef;


    @Override
    protected void onCreate(Bundle savedInstanceState)
    {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_create_category);

        category = new Category();
        etCreatedName = findViewById(R.id.et_createdName);
        etCate = findViewById(R.id.et_cate);
        btnNext = findViewById(R.id.btn_Next);
        btnDone1 = findViewById(R.id.btn_Done1);
        btnCancel2 = findViewById(R.id.btn_Cancel2);
        etGoal=findViewById(R.id.et_goal);

        btnLogoutCat = findViewById(R.id.logout);

        img = findViewById(R.id.btnImg);
        imgUploads = findViewById(R.id.btnUps);

        storage = FirebaseStorage.getInstance();
        storeRef = storage.getReference();

        ActionBar actionBar = getSupportActionBar();
        actionBar.setDisplayHomeAsUpEnabled(true);

        img.setOnClickListener(new View.OnClickListener()
        {
            @Override
            public void onClick(View view)
            {
                //Intent intent = new Intent(Intent.ACTION_PICK, MediaStore.Images.Media.EXTERNAL_CONTENT_URI);
                //startActivityForResult(intent, 3);

                OpenImage();
            }
        });

        imgUploads.setOnClickListener(new View.OnClickListener()
        {
            @Override
            public void onClick(View view)
            {
                upLoadImage();
            }
        });

        btnNext.setOnClickListener(new View.OnClickListener()
        {
            @Override
            public void onClick(View v)
            {

                /*String createdName = etCreatedName.getText().toString();
                String cate = etCate.getText().toString();
                String goal=etGoal.getText().toString();

                if (!TextUtils.isEmpty(createdName) && !TextUtils.isEmpty(cate) && !TextUtils.isEmpty(goal)) {
                    category.setCate(cate);
                    category.setCreatedName(createdName);
                    category.setGoal(goal);

                    heroCollec.push().setValue(category);
                    Intent intent = new Intent(CreateCategory.this, AddItems.class);
                    startActivity(intent);
                } else {
                    Toast.makeText(CreateCategory.this, "Please complete all fields", Toast.LENGTH_SHORT).show();
                }*/

                Intent intent = new Intent(CreateCategory.this, AddItems.class);
                startActivity(intent);
            }
        });

        btnDone1.setOnClickListener(new View.OnClickListener()
        {
            @Override
            public void onClick(View view)
            {
                Intent intent = new Intent(CreateCategory.this, MainMenu.class);
                startActivity(intent);
                String createdName = etCreatedName.getText().toString();
                String cate = etCate.getText().toString();
                String goal =etGoal.getText().toString();

                if (!TextUtils.isEmpty(createdName) && !TextUtils.isEmpty(cate) && !TextUtils.isEmpty(goal))
                {
                    category.setCate(cate);
                    category.setCreatedName(createdName);
                    category.setGoal(goal);

                    heroCollec.push().setValue(category);

                    String createdNam1 = etCreatedName.getText().toString();
                    Toast.makeText(CreateCategory.this, "Category " + createdNam1 + " has been created!", Toast.LENGTH_SHORT).show();

                }
                else
                {
                    Toast.makeText(CreateCategory.this, "Please complete all fields", Toast.LENGTH_SHORT).show();
                }
            }
        });

        btnCancel2.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent intent = new Intent(CreateCategory.this, MainMenu.class);
                startActivity(intent);
            }
        });

        btnLogoutCat.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent intent = new Intent(CreateCategory.this, MainActivity.class);
                startActivity(intent);
            }
        });


    }

    public boolean onOptionsItemSelected(@NonNull MenuItem item) {
        switch (item.getItemId()) {
            case android.R.id.home:
                this.finish();
                return true;
        }
        return super.onOptionsItemSelected(item);
    }

    /*@Override
    protected void onActivityResult(int requestCode, int resultCode, Intent data) {
        super.onActivityResult(requestCode,resultCode,data);
        if(resultCode == RESULT_OK && data !=null)
        {
            Uri selectedImage=data.getData();
            ImageView imageView =findViewById(R.id.imageView2);
            imageView.setImageURI(selectedImage);
        }
    }*/

    private void OpenImage()
    {
        Intent i = new Intent(Intent.ACTION_PICK, MediaStore.Images.Media.EXTERNAL_CONTENT_URI);

        //Intent i = new Intent();
        //i.setType("image/*");

        ///i.setAction(Intent.ACTION_GET_CONTENT);

        //startActivityForResult(Intent.createChooser(i, "Select Image from here..."),PICK_IMAGE_REQUEST);
        startActivityForResult(i, 3);
    }

    @Override
    protected void onActivityResult(int requestCode, int resultCode, @Nullable Intent data)
    {
        super.onActivityResult(requestCode, resultCode, data);

        if(resultCode == RESULT_OK && data != null)
        {
            /*selectImg = data.getData();
            try
            {
                Bitmap bitmap = MediaStore.Images.Media.getBitmap(getContentResolver(),selectImg);
                img.setImageBitmap(bitmap);
            }
            catch (IOException e)
            {
                e.printStackTrace();
            }*/
            selectImg = data.getData();
            imgShow = findViewById(R.id.imageView2);
            imgShow.setImageURI(selectImg);
        }
    }

    private void upLoadImage()
    {
        if(selectImg != null)
        {
            StorageReference ref = storeRef.child("images/" + UUID.randomUUID().toString());

            ref.putFile(selectImg).addOnSuccessListener(new OnSuccessListener<UploadTask.TaskSnapshot>()
            {
                @Override
                public void onSuccess(UploadTask.TaskSnapshot taskSnapshot)
                {
                    Toast.makeText(CreateCategory.this, "Image Uploaded!!", Toast.LENGTH_SHORT).show();
                }
            }).addOnFailureListener(new OnFailureListener()
            {
                @Override
                public void onFailure(@NonNull Exception e)
                {
                    Toast.makeText(CreateCategory.this, "Error! Image upload failed.", Toast.LENGTH_SHORT).show();
                }
            });
        }
    }
}

