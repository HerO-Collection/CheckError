package com.varsitycollege.herocollection;

public class Items {
    private String item;
    private String quantity;
    private String unit;
    private String description;
    private String selecCate;

    public Items() {

    }

    public Items(String item, String quantity,String unit,String description,String selecCate) {
        this.item = item;
        this.quantity = quantity;
        this.unit = unit;
        this.description = description;
        this.selecCate = selecCate;
    }
    public String getItem() {
        return item;
    }

    public void setItem(String item) {
        this.item = item;
    }

    public String getQuantity() {
        return quantity;
    }

    public void setQuantity(String quantity) {
        this.quantity = quantity;
    }

    public String getUnit() {
        return unit;
    }

    public void setUnit(String unit) {
        this.unit = unit;
    }

    public String getDescription() {
        return description;
    }

    public void setDescription(String description) {
        this.description = description;
    }

    public String getSelecCate() {
        return selecCate;
    }

    public void setSelecCate(String selecCate) {
        this.selecCate = selecCate;
    }

    @Override
    public String toString() {
        return "Items : " + item + '\n' +
                "Quantity: " + quantity + '\n' +
                "Units: " + unit + '\n' +
                "Description: " + description + '\n' +
                "Category: " + selecCate + '\n';
    }
}
