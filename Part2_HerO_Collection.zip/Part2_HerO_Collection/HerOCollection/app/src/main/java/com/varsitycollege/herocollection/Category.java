package com.varsitycollege.herocollection;

public class Category {
    private String createdName;
    private String cate;
    private String goal;


    public Category() {

    }

    public Category(String createdName, String cate,String goal) {
        this.createdName = createdName;
        this.cate = cate;
        this.goal=goal;
    }

    public String getCreatedName() {
        return createdName;
    }

    public void setCreatedName(String createdName) {
        this.createdName = createdName;
    }

    public String getCate() {
        return cate;
    }

    public void setCate(String cate) {
        this.cate = cate;
    }

    public String getGoal(){return goal;}

    public void setGoal(String goal){this.goal=goal;}

    @Override
    public String toString() {
        return "Category Name: " + createdName + '\n' +
                "Created: " + cate + '\n' +
                "Goal set: " + goal + '\n';
                //"Picture idk: ;
    }
}